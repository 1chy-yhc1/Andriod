> 有比较才会有优势，我们通常将Json与Xml进行比较，Json更加轻量。我觉得在某些程度上讲，这是一个仁者见仁智者见智的问题。例如有些人认为Json相比Xml更易读，有些人责认为不然，这里大致列举几条，仅供参考
 
 1. 结构简单，可读性更强，读写更加容易
 2. 格式是压缩的，占用带宽小
 3. 支持多种语言
 4. 因为JSON格式能够直接为服务器端代码使用,大大简化了服务器端和客户端的代码开发量
 
## 参考资料
[JSON与XML优缺点对比分析](http://www.jb51.net/article/69598.htm)

[百度百科](https://baike.baidu.com/item/JSON/2462549?fr=aladdin)

[Json官网](http://www.json.org/)