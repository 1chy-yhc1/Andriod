####  必知： 切换会先销毁再创建这个Activity
  竖切横屏执行的什么周期
   onPause
   onSaveInstanceState
   onStop 
   onDestroy
   onCreate
   onStart
   onRestoreInstanceState
   onResume
   横屏切竖屏执行的生命周期
   onPause
   onSaveInstanceState
   onStop
   onDestroy
   onCreate
   onStart
   onRestoreInstanceState
   onResume
####  必会：
设置Activity的android:configChanges 可以控制切换是否重建Activity
https://www.jianshu.com/p/dbc7e81aead2

