图片放这个文件夹内。

命名规则：英文小写+英文下划线。例如：android_binder.jpg

图片链接：https://github.com/jeanboydev/Android-Interview/blob/master/resources/images/xxx.png?raw=true

使用方式1：<img src="url" alt=""/>

使用方式2：![][url]