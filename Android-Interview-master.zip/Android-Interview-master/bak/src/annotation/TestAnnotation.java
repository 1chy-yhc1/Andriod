package annotation;

public @interface TestAnnotation {
}
