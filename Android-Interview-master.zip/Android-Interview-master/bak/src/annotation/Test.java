package annotation;

@TestAnnotation
public class Test {
}
